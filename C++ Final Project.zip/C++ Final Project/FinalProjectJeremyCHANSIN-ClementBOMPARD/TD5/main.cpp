//
//  main.cpp
//  TD5
//
//  Created by Jeremy Chansin on 03/11/2017.
//  Copyright © 2017 Jeremy Chansin. All rights reserved.
//
#include "EuropeanOption.hpp"
#include "PricerCRR.hpp"
#include <iostream>
#include "MonteCarlo.hpp"
using namespace std;
int main(int argc, const char * argv[]) {
    
    EuropeanOption opt1(0.01 , 0.2, 40, 200, 40, PUT);
    EuropeanOption opt2(0.01 , 0.2, 40, 200, 40, CALL);

    cout << "Price of put option : " << opt1.OptionPrice(20) << endl;
    cout << "Delta of put option : " << opt1.OptionDelta(20) << endl;
    
    cout << "Price of call option : " << opt2.OptionPrice(10) << endl;
    cout << "Delta of call option : " << opt2.OptionDelta(10) << endl;

    PricerCRR call (40, 10, 1, 0.01, 0.2, 20);
    PricerCRR put (40, 10, 1, 0.01, 0.2, 20);
    
    cout << "Call of CRR : " << call.CRR_call(40, 10, 1, 0.01, 0.2, 20) << endl;
    cout << "Put of CRR : " << put.CRR_put(40, 10, 1, 0.01, 0.2, 20) << endl;
    
    MonteCarlo Call (1,1,1,1,1,1);
    MonteCarlo Put (1,1,1,1,1,1);
    
    cout << "Call of MonteCarlo : " << Call.MonteCarloCall() << endl;
    cout << "Put of MonteCarlo : " <<Put.MonteCarloPut() << endl;
    system("pause");
    
    return 0;
}

