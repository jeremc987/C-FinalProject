//
//  PricerCRR.cpp
//  TD5
//
//  Created by Jeremy Chansin on 04/12/2017.
//  Copyright © 2017 Jeremy Chansin. All rights reserved.
//

#include "PricerCRR.hpp"
#include <math.h>
PricerCRR::PricerCRR(double _S, double _K, time_t _T,double _r, double _sigma, double _n)
{
    this->r = _r;
    this->sigma = _sigma;
    this->K = _K;
    this->T = _T;
    this->S = _S;
    this->n= _n;
   
}

double PricerCRR::binocoeff(double n, double j)
{
    int i;
    double b = 1;
    for (i = 0; i< j-1 ;i++)
    {
        b = b * (n - i) / (j-i);
    }
    return b;
}

PricerCRR::~PricerCRR(){}

double PricerCRR::CRR_call(double S, double K, time_t T,double r, double sigma, double n)
{
    double sdd;
    double j;
    double rr;
    double q;
    double u;
    double d;
    double bicomp;
    double sumbi = 0.0;
    double nj;
   
    rr = exp( (T / n) * r ) -1;
    sdd = sigma * sqrt(T / n);
    u = exp(rr + sdd);
    d = exp(rr - sdd);
    q = (1 + rr - d) / (u - d);
    for (j=1; j<n; j++)
    {
        nj = binocoeff(n, j);
        double aaa=nj * pow(q,j) * pow ((1-q),(n-j));
        double bbb = (S * pow (u,j) * pow (d,(n-j))-K);
        bicomp = aaa * bbb;
        if (bicomp <0)
        {
            bicomp = 0;
        }
        sumbi = sumbi + bicomp;
    }
    double call = sumbi / (pow (1+rr,n));
    return call;
}

double PricerCRR::CRR_put(double S, double K, time_t T,double r, double sigma, double n)
{
    double sdd;
    double j;
    double rr;
    double q;
    double u;
    double d;
    double bicomp;
    double sumbi = 0.0;
    double nj;
    S = 20;
    rr = exp( (T / n) * r ) -1;
    sdd = sigma * sqrt(T / n);
    u = exp(rr + sdd);
    d = exp(rr - sdd);
    q = (1 + rr - d) / (u - d);
    for (j=0; j<n; j++)
    {
        nj = binocoeff(n, j);
        bicomp = nj * pow(q,j) * pow ((1-q),(n-j)) * (K-(S * pow (u,j) * pow (d,(n-j))));
        if (bicomp <0)
        {
            bicomp = 0;
            sumbi = sumbi + bicomp;
        }
        sumbi = sumbi + bicomp;
    }
    double put = sumbi / (pow (1+rr,n));
    return put;
}


