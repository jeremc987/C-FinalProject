//
//  MonteCarlo.cpp
//  TD5
//
//  Created by Jeremy Chansin on 30/01/2018.
//  Copyright © 2018 Jeremy Chansin. All rights reserved.
//

#include "MonteCarlo.hpp"
#include <math.h>


MonteCarlo::MonteCarlo(double _StockPrice, double _StrikePrice, double _RiskFree, double _Volatile, double _Date, double _NbSimulations)

{
    this-> StockPrice = _StockPrice;
    this->StrikePrice = _StrikePrice;
    this->RiskFree = _RiskFree;
    this->Volatilite = _Volatile;
    this->Date = _Date;
    this->NbSimulations = _NbSimulations;
}


double MonteCarlo::normallaw(double value)
{
    return 0.5*erfc(-value *pow(sqrt(2), -1));
}
MonteCarlo::~MonteCarlo(){};

double MonteCarlo::PayOffMonteCarloCall(double StrikePrice, double Sti)

{
    double Z;
    Z = Sti;
    if (Z > StrikePrice) {
        Sti = Z - StrikePrice;
    }
    else {
        Sti = 0;
    }
    
    return Sti;
}
double MonteCarlo::PayOffMonteCarloPut(double StrikePrice, double Sti)
{
    double Z;
    Z = Sti;
    if (Z > StrikePrice) {
        Sti = StrikePrice - Z ;
    }
    else {
        Sti = 0;
    }
    
    return Sti;
}
double MonteCarlo::MonteCarloCall()
{
    int i;
    double sum = 0.0;
    double sti;
    sti=StockPrice;
    for (i=1; i < NbSimulations;i++) {
        sti= StockPrice * exp ((RiskFree-((pow(Volatilite,2))/2))*Date+Volatilite*sqrt(Date)*normallaw(20));
        sum = sum + PayOffMonteCarloCall(StrikePrice,Sti);
    }
    double Call = exp(-RiskFree*Date) * (1/NbSimulations) * sum;
    return Call;
}

double MonteCarlo::MonteCarloPut()
{
    int i;
    double sum = 0.0;
    double sti;
    sti=StockPrice;
    for (i=1; i < NbSimulations;i++) {
        sti= StockPrice * exp ((RiskFree-((pow(Volatilite,2))/2))*Date+Volatilite*sqrt(Date)*normallaw(20));
        sum = sum + PayOffMonteCarloPut(StrikePrice,Sti);
    }
    double Put = exp(-RiskFree*Date) * (1/NbSimulations) * sum;
    return Put;
}


