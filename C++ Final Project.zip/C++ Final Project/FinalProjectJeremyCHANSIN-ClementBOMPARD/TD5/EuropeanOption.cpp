//
//  EuropeanOption.cpp
//  TD5
//
//  Created by Jeremy Chansin on 03/11/2017.
//  Copyright © 2017 Jeremy Chansin. All rights reserved.
//
#include <ctime>
#include "EuropeanOption.hpp"
#include <iostream>
#include <cmath>
#define _USE_MATH_DEFINES
using namespace std;


EuropeanOption::EuropeanOption(double _r, double _sigma, double _K, time_t _T, double _S, TYPE _type)
{
    this->r = _r;
    this->sigma = _sigma;
    this->K = _K;
    this->T = _T;
    this->S = _S;
    this->type = _type;
}

double EuropeanOption::normalCFD(double value)
{
    return 0.5*erfc(-value *pow(sqrt(2), -1));
}

EuropeanOption::~EuropeanOption(){}

double EuropeanOption::OptionPrice(time_t t)
{
    double d1 = (log (S /K) + (r + 1/2 * sigma*sigma ) * (T-t)) / (sigma * sqrt(T-t));
    double d2 = d1 - sigma * sqrt(T-t);
    switch(type){
        case CALL:
            return S*normalCFD(d1) - K*exp(-r*(T - t))*normalCFD(d2);
            break;
            
        case PUT:
            return K*exp(-r*(T-t))*normalCFD(-d2)-S*normalCFD(-d1);
            break;
    }
    
}
double EuropeanOption::OptionDelta(time_t t)
{
    double d1 = (log (S /K) + (r + 1/2 * sigma*sigma ) * (T-t)) / (sigma * sqrt(T-t));
    switch (type) {
        case CALL:
            return normalCFD(d1);
            break;
            
        case PUT:
            return -normalCFD(-d1);
            break;
    }
}
