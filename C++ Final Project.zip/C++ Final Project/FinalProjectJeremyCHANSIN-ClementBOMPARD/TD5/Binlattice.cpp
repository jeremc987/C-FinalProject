//
//  Binlattice.cpp
//  TD5
//
//  Created by Jeremy Chansin on 31/01/2018.
//  Copyright © 2018 Jeremy Chansin. All rights reserved.
//
/*
#include "Binlattice.hpp"
template <typename T>
void BinLattice<T>::setN(int N)
{
    this ->N=N;
    lattice = vector <vector <T> > (N+1);
    for (int i=0; i<= N; i++)
    {
        lattice [i] = vector <T> (i+1);
    }
}

template <typename T>
*/
