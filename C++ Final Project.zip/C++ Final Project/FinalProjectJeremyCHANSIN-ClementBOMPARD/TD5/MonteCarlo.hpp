//
//  MonteCarlo.hpp
//  TD5
//
//  Created by Jeremy Chansin on 30/01/2018.
//  Copyright © 2018 Jeremy Chansin. All rights reserved.
//

#define MonteCarlo_hpp

#include <stdio.h>

class MonteCarlo{
protected:
    double StockPrice;
    double StrikePrice;
    double RiskFree;
    double Volatilite;
    double Date;
    double NbSimulations;
    double Sti;
    double normallaw(double value);
    
    
public:
    MonteCarlo(double StockPrice, double StrikePrice, double RiskFree, double Volatilite, double Date, double NbSimulations);
    ~MonteCarlo();
    double MonteCarloCall();
    double MonteCarloPut();
    double PayOffMonteCarloCall(double StrikePrice, double Sti);
    double PayOffMonteCarloPut(double StrikePrice, double Sti);
};

