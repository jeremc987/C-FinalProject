//
//  Binlattice.hpp
//  TD5
//
//  Created by Jeremy Chansin on 31/01/2018.
//  Copyright © 2018 Jeremy Chansin. All rights reserved.
//
/*
#ifndef Binlattice_hpp
#define Binlattice_hpp
#pragma once
#include <stdio.h>
#include <iostream>
#include <vector>
using namespace std;

template <typename T>
#endif /* Binlattice_hpp */
/*class BinLattice{
    int N;
    vector <vector<T>>lattice;
    
public:
    void setN(int N);
    void setNode(int n,int i, T val) { lattice[n][i]= val; }
    T & getNode() {return lattice[n][i]; }
};
