//
//  PricerCRR.hpp
//  TD5
//
//  Created by Jeremy Chansin on 04/12/2017.
//  Copyright © 2017 Jeremy Chansin. All rights reserved.
//

#ifndef PricerCRR_hpp
#define PricerCRR_hpp
#include <stdio.h>
#include <ctime>


#endif /* PricerCRR_hpp */

class PricerCRR{
   
protected:
    
    
    double S; //sous-jacent
    double K; //Strike
    time_t T; //Date expiration
    double r; // Taux sans risque
    double sigma; //volatilité
    double n; //Nb de simulation
    double binocoeff(double n, double j);

public :
    PricerCRR(double S, double K, time_t T,double r, double sigma, double n);
    ~ PricerCRR();
    double CRR_call(double S, double K, time_t T,double r, double sigma, double n);
    double CRR_put(double S, double K, time_t T,double r, double sigma, double n);
    
    
};
