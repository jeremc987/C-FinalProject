//
//  EuropeanOption.hpp
//  TD5
//
//  Created by Jeremy Chansin on 03/11/2017.
//  Copyright © 2017 Jeremy Chansin. All rights reserved.
//

#ifndef EuropeanOption_hpp
#define EuropeanOption_hpp
#pragma once
#include <iostream>
#include <cmath>
#include <stdio.h>
#include <ctime>
#include <string>
using namespace std;
#endif /* EuropeanOption_hpp */
enum TYPE {CALL,PUT};
class EuropeanOption{
    
protected:
    double K; //Strike price
    double r;// interest rate
    double sigma; //Volatility
    double S; //underlying price
    time_t T; //Expiry date
    TYPE type;
    double normalCFD(double value);
    
public:
    EuropeanOption(double r,double sigma, double K,time_t T,double S,TYPE type);
    ~EuropeanOption();
    double OptionPrice(time_t);
    double OptionDelta(time_t);
    
};
